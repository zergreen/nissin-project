const itemSchema = new mongoose.Schema({
    name: String,
    quantity: Number,
    description: String
});

const inventorySchema = new mongoose.Schema({
    storeLocation: String,
    items: [itemSchema]  // Array of item objects
});

const Inventory = mongoose.model('Inventory', inventorySchema);