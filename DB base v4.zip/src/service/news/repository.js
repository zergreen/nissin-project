module.exports = {
    newsModel: {
        id: '',
        newsId:'',
        topic: '',
        date: '',
        detail: '',
        category: '',
        image: '',
        link: '',
    },
    newsSchema: {
        id: '',
        newsId:'',
        topic: '',
        date: '',
        detail: '',
        category: '',
        image: '',
        link: '',
    }
}