module.exports = {
    loginModel: {
        id: '',
        loginId:'',
        username:'',
        password:'',
        lname:'',
        email:'',
        year:'',
        branch: '',
    },
    loginSchema: {
        id: '',
        loginId:'',
        username:'',
        password:'',
        lname:'',
        email:'',
        year:'',
        branch: '',
    }
}