module.exports = {
    applyModel: {
        id: '',
        applyId: '',
        username:'',
        name:'',
        branch:'',
        year:'',
    },
    applySchema: {
        id: '',
        applyId: '',
        username:'',
        name:'',
        branch:'',
        year:'',
    }
}